<?php
// AlexHorse Scent Passport — photo recognition endpoint.
// Receives a label close-up (and optionally the whole frame) from the app,
// asks a Claude vision model which catalogue code it is, returns JSON.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$cfgFile = __DIR__ . '/config.php';
if (!is_file($cfgFile)) { http_response_code(503); echo json_encode(['error' => 'not_configured']); exit; }
$cfg = require $cfgFile;
$key = $cfg['api_key'] ?? '';
if (!$key || strpos($key, 'sk-ant-') !== 0) { http_response_code(503); echo json_encode(['error' => 'not_configured']); exit; }

// same-site only
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = $cfg['allowed_origins'] ?? [];
if ($origin && $allowed && !in_array($origin, $allowed, true)) { http_response_code(403); echo json_encode(['error' => 'origin']); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error' => 'method']); exit; }

// simple per-IP limit: 40 photos per 10 minutes
$ip = $_SERVER['REMOTE_ADDR'] ?? 'x';
$rl = sys_get_temp_dir() . '/ah_rl_' . md5($ip);
$now = time(); $hits = [];
if (is_file($rl)) { $hits = array_filter(explode(',', (string)file_get_contents($rl)), fn($t) => $t && $now - (int)$t < 600); }
if (count($hits) >= ($cfg['max_per_10min'] ?? 40)) { http_response_code(429); echo json_encode(['error' => 'rate_limited']); exit; }
$hits[] = $now; @file_put_contents($rl, implode(',', $hits));

$in = json_decode(file_get_contents('php://input'), true);
function img_block($dataUrl) {
  if (!is_string($dataUrl) || !preg_match('#^data:(image/(?:jpeg|png|webp));base64,(.+)$#', $dataUrl, $m)) return null;
  if (strlen($m[2]) > 4 * 1024 * 1024) return null;
  return ['type' => 'image', 'source' => ['type' => 'base64', 'media_type' => $m[1], 'data' => $m[2]]];
}
$crop = img_block($in['crop'] ?? null);
if (!$crop) { http_response_code(400); echo json_encode(['error' => 'no_image']); exit; }
$content = [['type' => 'text', 'text' => 'Close-up of the label area:'], $crop];
$full = img_block($in['full'] ?? null);
if ($full) { $content[] = ['type' => 'text', 'text' => 'Whole frame for context:']; $content[] = $full; }
$content[] = ['type' => 'text', 'text' => 'Which product is this? Reply with the JSON only.'];

$body = [
  'model' => $cfg['model'] ?? 'claude-haiku-5-5',
  'max_tokens' => 300,
  'system' => [['type' => 'text', 'text' => file_get_contents(__DIR__ . '/prompt.txt'), 'cache_control' => ['type' => 'ephemeral']]],
  'messages' => [['role' => 'user', 'content' => $content]],
];
$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
  CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25,
  CURLOPT_HTTPHEADER => ['content-type: application/json', 'x-api-key: ' . $key, 'anthropic-version: 2023-06-01'],
  CURLOPT_POSTFIELDS => json_encode($body),
]);
$res = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
if ($res === false || $code !== 200) { http_response_code(502); echo json_encode(['error' => 'upstream', 'status' => $code]); exit; }
$j = json_decode($res, true);
$text = '';
foreach (($j['content'] ?? []) as $b) if (($b['type'] ?? '') === 'text') $text .= $b['text'];
if (!preg_match('/\{.*\}/s', $text, $m)) { echo json_encode(['codes' => [], 'confident' => false, 'read' => '']); exit; }
$out = json_decode($m[0], true) ?: [];
$valid = array_flip(array_map(fn($l) => explode('|', $l)[0], array_filter(explode("\n", (string)file_get_contents(__DIR__ . '/catalog.txt')))));
$codes = array_values(array_filter((array)($out['codes'] ?? []), fn($c) => is_string($c) && isset($valid[$c])));
echo json_encode(['codes' => array_slice($codes, 0, 4), 'confident' => !empty($out['confident']) && $codes, 'read' => (string)($out['read'] ?? '')], JSON_UNESCAPED_UNICODE);
