<?php
// Copy this file to config.php and paste your Anthropic API key.
// Key: https://console.anthropic.com → API Keys. Keep config.php private (never commit it).
return [
  'api_key' => 'sk-ant-...',
  'model' => 'claude-haiku-5-5',          // fast and cheap; 'claude-sonnet-5-5' is more accurate on hard photos
  'allowed_origins' => ['https://app.alexhorse.de', 'https://alexhorse.de'],
  'max_per_10min' => 40,                  // photos per device IP
];
